let contractAbi = require("./contract_abi");
function fst_transaction(url) {
    this.url = url;
    this.storm3 = "undefined";
    if (typeof fst_transaction._initialized == "undefined") {
        fst_transaction.prototype.init = function() {
            if(this.storm3 == "undefined"){
                this.storm3 = new Storm3(new Storm3.providers.HttpProvider(this.url));
            }
        };

        if (typeof this.getBalance != "function") {
            fst_transaction.prototype.getBalance = async function(address) {
                let balance =await this.storm3.fst.getBalance(address);
                return balance;
            }
        }

        if (typeof this.getGasPrice != "function") {
            fst_transaction.prototype.getGasPrice = async function() {
                let GasPrice =await this.storm3.fst.getGasPrice();
                return GasPrice;

            }
        }

        if (typeof this.sendtransaction != "function") {
            fst_transaction.prototype.sendtransaction = async function(txData,secret) {
                let tx = await this.storm3.fst.accounts.signTransaction(txData,secret)
                let raw = tx.rawTransaction
                let hash = await this.storm3.fst.sendSignedTransaction(raw)
                return hash;
            }
        }

        if (typeof this.getGasPrice != "function") {
            fst_transaction.prototype.getGasPrice = async function() {
                let GasPrice = await this.storm3.fst.getGasPrice()
                return GasPrice;
            }
        }

        if (typeof this.isValueAddress != "function") {
            fst_transaction.prototype.isValueAddress = async function(address) {
                let result = await this.storm3.fst.isValueAddress(address)
                return result;
            }
        }

        if (typeof this.getTransactionDetail != "function") {
            fst_transaction.prototype.getTransactionDetail = async function(hash) {
                let Detail = await this.storm3.fst.getTransaction(hash)
                return Detail;
            }
        }

        if (typeof this.getTransactionReceipt != "function") {
            fst_transaction.prototype.getTransactionReceipt = async function(hash) {
                let Receipt = await this.storm3.fst.getTransactionReceipt(hash)
                let BlockData = await this.storm3.fst.getBlock(Receipt.blockNumber)
                Receipt.timestamp = BlockData.timestamp;
                return Receipt;
            }
        }

        if (typeof this.isValueSecret != "function") {
            fst_transaction.prototype.isValueSecret = async function(secret) {
                let result = await this.storm3.fst.isValueSecret(secret);
                return result;
            }
        }

        if (typeof this.isValueSecret != "function") {
            fst_transaction.prototype.isValueSecret = async function(secret) {
                let result = await this.storm3.fst.getTransactionReceipt(secret);
                return result;
            }
        }

        if (typeof this.SignTransaction != "function") {
            fst_transaction.prototype.SignTransaction = function(params) {
                let paramsjson = JSON.parse(params);
                let address = paramsjson.address;
                let to = paramsjson.to;
                let value = paramsjson.value
                let gasPrice = paramsjson.gasPrice
                let gasLimit = paramsjson.gasLimit
                let data = paramsjson.data
                let txData = {
                    "to": this.storm3.utils.toHex(to),
                    "from": this.storm3.utils.toHex(address),
                    "gasPrice": this.storm3.utils.toHex(gasPrice),
                    "gas": this.storm3.utils.toHex(gasLimit),
                    "value": this.storm3.utils.toHex(value),
                    "data": this.storm3.utils.toHex(data),
                }
                return txData;
            }
        }

        fst_transaction._initialized = true;
    }
}

function fst_erc20_transaction(url,contract,address) {
    this.url = url;
    this.storm3 = "undefined";
    this.myContract = "undefined";
    this.currentAddress = address;
    this.contractAddress = contract;

    if (typeof fst_erc20_transaction._initialized == "undefined") {
        fst_erc20_transaction.prototype.init = async function() {
            if(this.storm3 == "undefined"){
                this.storm3 = new Storm3(new Storm3.providers.HttpProvider(this.url));
                this.myContract = new this.storm3.fst.Contract(contractAbi, this.contractAddress, {
                    from: this.currentAddress,
                });
            }
        };

        if (typeof this.getErc20Balance != "function") {
            fst_erc20_transaction.prototype.getErc20Balance = async function(address) {
                await this.init();
                let balance = await this.myContract.methods.balanceOf(address).call();
                return balance;
            }
        }

        if (typeof this.sendErc20Transaction != "function") {
            fst_erc20_transaction.prototype.sendErc20Transaction = async function(serializedTx) {
                await this.init();
                let hash = this.storm3.fst.sendSignedTransaction('0x' + serializedTx.toString('hex'));
                return hash;
            }
        }

        if (typeof this.SignErc20Transaction != "function") {
            fst_erc20_transaction.prototype.SignErc20Transaction = async function(params) {
                await this.init();
                let paramsjson = JSON.parse(params);
                let contractAddress = paramsjson.contract;
                let currentAccount = paramsjson.address;
                let to = paramsjson.to;
                let secret = paramsjson.secret;
                let gasLimit = paramsjson.gasLimit
                let value = paramsjson.value
                let gasPrice = paramsjson.gasPrice
                let nonce = await this.storm3.fst.getTransactionCount(address, this.storm3.fst.defaultBlock.pending)
                let txData = {
                    nonce: this.storm3.utils.toHex(nonce++),
                    gasLimit: this.storm3.utils.toHex(gasLimit),
                    gasPrice: this.storm3.utils.toHex(gasPrice),
                    // 注意这里是代币合约地址
                    to: contractAddress,
                    from: currentAccount,
                    // 调用合约转账value这里留空
                    value: '0x00',
                    // data的组成，由：0x + 要调用的合约方法的function signature + 要传递的方法参数，每个参数都为64位(对transfer来说，第一个是接收人的地址去掉0x，第二个是代币数量的16进制表示，去掉前面0x，然后补齐为64位)
                    data: '0x' + 'a9059cbb' + addPreZero(to.substr(2)) + addPreZero(this.storm3.utils.toHex(value).substr(2))
                }
                let tx = new Tx(txData);
                let privateKey = Buffer.from(secret.substr(2),'hex');
                tx.sign(privateKey);
                let serializedTx = tx.serialize().toString('hex');
                return serializedTx;
            }
        }
7
        fst_erc20_transaction._initialized = true;
    }
}

exports.fst_transaction = fst_transaction;
exports.fst_erc20_transaction = fst_erc20_transaction;